
public class Monster extends Character
{
	public Monster(String iD, String name, String preExisting, String spawn, String monsterDies,
			String playerDies, int damage, int health) {
		super(iD, name, preExisting, spawn, monsterDies, playerDies, damage, health);
	}
}
